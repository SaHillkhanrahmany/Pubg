# Facebook-Random-Hack
Facebook Account Cloning and random hack by ID

<hr>
<img src="https://i.ibb.co/1TncGNg/Screenshot-202405031-171207-1.jpg">
<h3>Installation</h3>
<b>
apt update ; apt upgrade <br>
pkg install git <br>
pkg install php <br>
git clone https://github.com/renlowsphere/Facebook-Random-Hack <br>
cd Facebook-Random-Hack <br>
php fb.php

